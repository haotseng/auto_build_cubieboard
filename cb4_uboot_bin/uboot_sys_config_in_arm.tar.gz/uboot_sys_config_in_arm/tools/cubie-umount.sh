#!/bin/sh


/bin/umount /dev/$1
rmdir /media/$1 

